# My Pizza

```bash
First buy pizza crust
Second put toppings
Third place it in the oven