Pizza crust
Tomato Sauce
Onions
Cheese
Tomatos 
Green Peppers